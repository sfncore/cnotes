import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { useBlockNoteSync } from "@convex-dev/prosemirror-sync/blocknote";
import { BlockNoteView } from "@blocknote/mantine";
import { BlockNoteEditor } from "@blocknote/core";
import usePresence from "@convex-dev/presence/react";
import FacePile from "@convex-dev/presence/facepile";
import { useState, useEffect } from "react";
import { Edit3, Globe, Lock } from "lucide-react";
import { toast } from "sonner";

import "@blocknote/core/fonts/inter.css";
import "@blocknote/mantine/style.css";

interface DocumentEditorProps {
  documentId: Id<"documents">;
}

export function DocumentEditor({ documentId }: DocumentEditorProps) {
  const document = useQuery(api.documents.get, { id: documentId });
  const userId = useQuery(api.presence.getUserId);
  const updateTitle = useMutation(api.documents.updateTitle);
  
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleValue, setTitleValue] = useState("");

  const sync = useBlockNoteSync<BlockNoteEditor>(api.prosemirror, documentId);
  const presenceState = usePresence(api.presence, documentId, userId || "");

  useEffect(() => {
    if (document) {
      setTitleValue(document.title);
    }
  }, [document]);

  const handleTitleSubmit = async () => {
    if (!titleValue.trim() || !document) return;
    
    try {
      await updateTitle({
        id: documentId,
        title: titleValue.trim(),
      });
      setIsEditingTitle(false);
      toast.success("Title updated");
    } catch (error) {
      toast.error("Failed to update title");
      setTitleValue(document.title);
    }
  };

  const handleTitleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleTitleSubmit();
    } else if (e.key === "Escape") {
      setTitleValue(document?.title || "");
      setIsEditingTitle(false);
    }
  };

  if (!document) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading document...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Document Header */}
      <div className="border-b border-gray-200 px-8 py-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3 flex-1">
            {isEditingTitle ? (
              <input
                type="text"
                value={titleValue}
                onChange={(e) => setTitleValue(e.target.value)}
                onBlur={handleTitleSubmit}
                onKeyDown={handleTitleKeyDown}
                className="text-3xl font-bold text-gray-900 bg-transparent border-none outline-none focus:ring-0 p-0 flex-1"
                autoFocus
              />
            ) : (
              <h1
                onClick={() => setIsEditingTitle(true)}
                className="text-3xl font-bold text-gray-900 cursor-pointer hover:bg-gray-50 px-2 py-1 rounded -mx-2 -my-1 transition-colors flex items-center space-x-2"
              >
                <span>{document.title}</span>
                <Edit3 size={20} className="text-gray-400 opacity-0 group-hover:opacity-100" />
              </h1>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              {document.isPublic ? (
                <>
                  <Globe size={16} className="text-green-500" />
                  <span>Public</span>
                </>
              ) : (
                <>
                  <Lock size={16} className="text-gray-400" />
                  <span>Private</span>
                </>
              )}
            </div>
            
            {presenceState && presenceState.length > 0 && (
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Collaborators:</span>
                <FacePile presenceState={presenceState} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full max-w-4xl mx-auto px-8 py-8">
          {sync.isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading editor...</p>
              </div>
            </div>
          ) : sync.editor ? (
            <div className="prose prose-lg max-w-none">
              <BlockNoteView 
                editor={sync.editor} 
                theme="light"
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-64">
              <button
                onClick={() => sync.create({ type: "doc", content: [] })}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Initialize Document
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
